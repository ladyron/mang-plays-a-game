
//{{BLOCK(startBg1)

//======================================================================
//
//	startBg1, 256x256@8, 
//	+ palette 256 entries, not compressed
//	+ 292 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 18688 + 2048 = 21248
//
//	Time-stamp: 2022-11-09, 16:34:06
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTBG1_H
#define GRIT_STARTBG1_H

#define startBg1TilesLen 18688
extern const unsigned short startBg1Tiles[9344];

#define startBg1MapLen 2048
extern const unsigned short startBg1Map[1024];

#define startBg1PalLen 512
extern const unsigned short startBg1Pal[256];

#endif // GRIT_STARTBG1_H

//}}BLOCK(startBg1)
