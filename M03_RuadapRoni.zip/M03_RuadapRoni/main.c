// What is finished:
// • enemy sprites, animation
// • ball-enemy collision
// What needs to be added:
// • music and sound
// • more animation
// • enemy movement
// How to play (for now):
// • press B to throw ball
// • if enemy lives == 0, player wins
// • if player lives == 0, player loses

#include <stdlib.h>
#include "gba.h" // Mode 0 Scaffold
#include "print.h"
#include "startBg.h"
#include "startBg1.h"
#include "startBg2.h"
#include "pauseBg1.h"
#include "pauseBg2.h"
#include "gameBg.h"
#include "winBg.h"
#include "loseBg.h"
#include "game.h"
#include "instructionsBg.h"

void initialize();

void goToStart();
void goToStart2();
void goToInstructions();
void goToGame();
void goToPause();
void goToPause2();
void goToWin();
void goToLose();

void start();
void start2();
void instructions();
void game();
void pause();
void pause2();
void win();
void lose();

enum {START1, START2, INSTRUCTIONS, GAME, PAUSE1, PAUSE2, WIN, LOSE};
int state;

unsigned short buttons;
unsigned short oldButtons;

int seed;

OBJ_ATTR shadowOAM[128];

int main() {
    
    initialize();

    while(1) {
        oldButtons = buttons;
        buttons = BUTTONS;

         switch (state) {
            case START1:
                start();
                break;
            case START2:
                start2();
                break;
            case INSTRUCTIONS:
                instructions();
                break;
            case GAME:
                game();
                break;
            case PAUSE1:
                pause();
                break;
            case PAUSE2:
                pause2();
                break;
            case WIN:
                win();
                break;
            case LOSE:
                lose();
                break;    
        }
    }
}

void initialize() {

    REG_DISPCTL = MODE0 | BG2_ENABLE | SPRITE_ENABLE;

    REG_BG2CNT = BG_8BPP | BG_SIZE_WIDE | BG_CHARBLOCK(0) | BG_SCREENBLOCK(31);

    buttons = BUTTONS;
    oldButtons = 0;

    goToStart();
}

void goToStart() {

    DMANow(3, &startBg1Pal, PALETTE, 256);
    DMANow(3, &startBg1Tiles, &CHARBLOCK[0], startBg1TilesLen / 2);
    DMANow(3, &startBg1Map, &SCREENBLOCK[31], startBg1MapLen / 2);

    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);
    waitForVBlank();

    state = START1;

    seed = 0;
}

void start() {
    seed++;

    waitForVBlank();
    
    if (BUTTON_PRESSED(BUTTON_A)) {
        srand(seed);
        goToGame();
        initGame();
    }
    if (BUTTON_PRESSED(BUTTON_DOWN)) {
        goToStart2();
    }
}

void goToStart2() {

    DMANow(3, &startBg2Pal, PALETTE, 256);
    DMANow(3, &startBg2Tiles, &CHARBLOCK[0], startBg2TilesLen / 2);
    DMANow(3, &startBg2Map, &SCREENBLOCK[31], startBg2MapLen / 2);

    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);
    waitForVBlank();

    state = START2;

    seed = 0;

}

void start2() {

    seed++;

    waitForVBlank();
    
    if (BUTTON_PRESSED(BUTTON_A)) {
        goToInstructions();
    }
    if (BUTTON_PRESSED(BUTTON_UP)) {
        goToStart();
    }  
}

void goToInstructions() {
    DMANow(3, &instructionsBgPal, PALETTE, 256);
    DMANow(3, &instructionsBgTiles, &CHARBLOCK[0], instructionsBgTilesLen / 2);
    DMANow(3, &instructionsBgMap, &SCREENBLOCK[31],instructionsBgMapLen / 2);

    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);
    waitForVBlank();

    state = INSTRUCTIONS;

    seed = 0;

}

void instructions() {
    if (BUTTON_PRESSED(BUTTON_A)) {
        goToStart();
    }
}

void goToGame() {    
    DMANow(3, &gameBgPal, PALETTE, 256);
    DMANow(3, &gameBgTiles, &CHARBLOCK[0], gameBgTilesLen / 2);
    DMANow(3, &gameBgMap, &SCREENBLOCK[31], gameBgMapLen / 2);
    
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);
    waitForVBlank();

    state = GAME;
}

void game() {

    updateGame();
    drawGame();
    
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    if (BUTTON_PRESSED(BUTTON_START)) {
        goToPause();
    }
    if (ballsLeft == 0) {
        goToWin();
    }
    if (mang.health == 0) {
        goToLose(); // test
    }
    if (van.health == 0 && cooky.health == 0 && koya.health == 0) {
        goToWin();
    }

}

void goToPause() {
    DMANow(3, pauseBg1Pal, PALETTE, 256);
    DMANow(3, pauseBg1Tiles, &CHARBLOCK[0], pauseBg1TilesLen / 2);
    DMANow(3, pauseBg1Map, &SCREENBLOCK[31], pauseBg1MapLen / 2);
    
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);
    waitForVBlank();

    state = PAUSE1;
}

void pause() {
    waitForVBlank();

    if (BUTTON_PRESSED(BUTTON_RIGHT)) {
        goToPause2();
    }
    if (BUTTON_PRESSED(BUTTON_A)) {
        goToGame();
    }
}

void goToPause2() {
    DMANow(3, pauseBg2Pal, PALETTE, 256);
    DMANow(3, pauseBg2Tiles, &CHARBLOCK[0], pauseBg2TilesLen / 2);
    DMANow(3, pauseBg2Map, &SCREENBLOCK[31], pauseBg2MapLen / 2);
    
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);
    waitForVBlank();

    state = PAUSE2;
} 

void pause2() {

    if (BUTTON_PRESSED(BUTTON_LEFT)) {
        goToPause();
    }
    if (BUTTON_PRESSED(BUTTON_A)) {
        goToStart();
    }
}
void goToWin() {
    DMANow(3, winBgPal, PALETTE, 256);
    DMANow(3, winBgTiles, &CHARBLOCK[0], winBgTilesLen / 2);
    DMANow(3, winBgMap, &SCREENBLOCK[31], winBgMapLen / 2);
    
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);
    waitForVBlank();

    state = WIN;
}

void win() {
    waitForVBlank();

    if (BUTTON_PRESSED(BUTTON_A))
        goToStart();
}

void goToLose() {

    DMANow(3, loseBgPal, PALETTE, 256);
    DMANow(3, loseBgTiles, &CHARBLOCK[0], loseBgTilesLen / 2);
    DMANow(3, loseBgMap, &SCREENBLOCK[31], loseBgMapLen / 2);
    
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);
    waitForVBlank();

    state = LOSE;
}

void lose() {
    waitForVBlank();

    if (BUTTON_PRESSED(BUTTON_A))
        goToStart();
} 

